package array.demo;

public class GreatestNumber {
	public static void main (String[] args) {
		int a=3;
		int b=4;
		int c=5;
		if (a>b && a>c){
			System.out.println("a is the the greatest number");
		}else if(b>a&&b>c){
			System.out.println("b is the greatest number");
		}else {
			System.out.println(" c is the greatest number");
		}
		
	}

}

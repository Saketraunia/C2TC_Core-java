package array.demo;

public class Star6 {
	public static void  main(String args[]) {
		
		
	}

}

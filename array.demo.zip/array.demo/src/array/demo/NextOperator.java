package array.demo;

public class NextOperator
{
	public static void main(String[] args) {
	int a=5;
	int b=6;
	if(a>b) {
		System.out.println("a is the greatest"+ a);
	}
	else {
		System.out.println("b is the greatest no"+  b);
	}
	}
}

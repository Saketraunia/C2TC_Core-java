package array.demo;

public class FirstArray {
	public static void main(String args[]) {
	// declare an array
	int [] Anarray;
	// declare the size of an array
	Anarray =new int[5];
	// initialize an ARRay
	Anarray [0]=1;
	Anarray [1]=2;
	System.out.println("element at index at o:"+ Anarray[0]);	}
}

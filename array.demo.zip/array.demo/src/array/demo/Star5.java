package array.demo;

import java.util.Scanner;
public class Star5 {
	char ch ='c';
	int  var = 45 
	ch=num;
	
	System.out.println(ch);
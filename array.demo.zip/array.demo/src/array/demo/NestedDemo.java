package array.demo;

public class NestedDemo
{
	public static void main(String[] args)
	{
		int a=50;
		if(a==50)
		{
			System.out.println(" i is to 50");
			if(a>=60)
			{
				System.out.println(" a  is greater than 60");
			}
			else 
			{
				System.out.println(" a is smaller than 60");
			}
				
		}
	}

}
